package com.example.travelsmart;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MetroMapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro_map);
    }
}