package com.example.travelsmart;

public class ReadWriteQrCode {
    public String Qrcode;

    //constructor
    public ReadWriteQrCode(){};
    public ReadWriteQrCode(String Qrcodedata)
    {

        this.Qrcode=Qrcodedata;
    }

}
